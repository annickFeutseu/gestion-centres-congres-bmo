import React, { CSSProperties } from "react";
import {
  Legend,
  PolarAngleAxis,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

interface SeriesConfig {
  name: string;
  color?: string;
}

interface Props {
  id: string;
  title?: string;
  color?: string;
  data: any[];
  labelField: string;
  dataField: string;
  series?: SeriesConfig[];
  options?: Record<string, any>;
  styles?: CSSProperties;
}

const defaultSeriesColors = ["#4a90e2", "#10B981", "#F97316", "#F43F5E", "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16"];

// Helper to get nested values using dot notation (e.g., "measures.value")
const getNestedValue = (obj: any, path: string): any => {
  if (!obj || !path) return undefined;
  const parts = path.split('.');
  let current = obj;
  for (const part of parts) {
    if (current === null || current === undefined) return undefined;
    if (Array.isArray(current)) {
      current = current[0];
      if (current === undefined) return undefined;
    }
    current = current[part];
  }
  return current;
};

const resolveFill = (
  explicit?: string,
  options?: Record<string, any>,
  styles?: CSSProperties
) =>
  explicit ||
  options?.barColor ||
  (styles && (styles as any)["--chart-bar-color"]) ||
  "#EC4899";

export const RadialBarChartComponent: React.FC<Props> = ({
  id,
  title,
  color,
  data,
  labelField,
  dataField,
  series,
  options,
  styles,
}) => {
  // Transform data if using nested fields (dot notation)
  const isNestedField = (field: string) => field?.includes('.') || false;
  const chartData = React.useMemo(() => {
    if (series && series.length > 0) {
      return data;
    }
    if (!isNestedField(labelField) && !isNestedField(dataField)) {
      return data; // No transformation needed
    }
    return data.map((item: any) => ({
      name: isNestedField(labelField) ? getNestedValue(item, labelField) : item[labelField],
      value: isNestedField(dataField) ? getNestedValue(item, dataField) : item[dataField],
    }));
  }, [data, labelField, dataField, series]);

  // Use transformed field names if we did transformation
  const actualLabelField =
    series && series.length > 0
      ? "name"
      : (isNestedField(labelField) || isNestedField(dataField)) ? 'name' : labelField;
  const actualDataField =
    series && series.length > 0
      ? series[0]?.name || 'value'
      : (isNestedField(labelField) || isNestedField(dataField)) ? 'value' : dataField;

  const containerStyle: CSSProperties = {
    width: "100%",
    minHeight: "320px",
    marginBottom: "20px",
    ...styles,
  };

  const showLegend = options?.showLegend ?? true;
  const showTooltip = options?.showTooltip ?? true;

  return (
    <div id={id} style={containerStyle}>
      {title && <h3 style={{ textAlign: "center" }}>{title}</h3>}
      <ResponsiveContainer width="100%" height="80%">
        <RadialBarChart
          data={chartData}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
          innerRadius={options?.innerRadius || 20}
          outerRadius={options?.outerRadius || 140}
          startAngle={options?.startAngle || 0}
          endAngle={options?.endAngle || 360}
        >
          {PolarAngleAxis({ dataKey: actualLabelField })}
          {(series && series.length > 0 ? series : [{ name: actualDataField, color }]).map((s, index) => (
            <RadialBar
              key={s.name || index}
              background
              dataKey={s.name || actualDataField}
              name={s.name || actualDataField}
              fill={
                s.color ||
                resolveFill(color, options, styles) ||
                defaultSeriesColors[index % defaultSeriesColors.length]
              }
            />
          ))}
          {showTooltip && <Tooltip />}
          {showLegend && <Legend verticalAlign={options?.legendPosition || "bottom"} />}
        </RadialBarChart>
      </ResponsiveContainer>
    </div>
  );
};