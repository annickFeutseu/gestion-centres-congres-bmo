import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { TableProvider } from "./contexts/TableContext";
import Gestionnaire from "./pages/Gestionnaire";
import Indisponibilite from "./pages/Indisponibilite";
import Centrecongres from "./pages/Centrecongres";
import Element from "./pages/Element";
import Evenement from "./pages/Evenement";
import Reservation from "./pages/Reservation";
import Supplement from "./pages/Supplement";
import Materiel from "./pages/Materiel";
import Prestation from "./pages/Prestation";
import Tarif from "./pages/Tarif";

function App() {
  return (
    <TableProvider>
      <div className="app-container">
        <main className="app-main">
          <Routes>
            <Route path="/gestionnaire" element={<Gestionnaire />} />
            <Route path="/indisponibilite" element={<Indisponibilite />} />
            <Route path="/centrecongres" element={<Centrecongres />} />
            <Route path="/element" element={<Element />} />
            <Route path="/evenement" element={<Evenement />} />
            <Route path="/reservation" element={<Reservation />} />
            <Route path="/supplement" element={<Supplement />} />
            <Route path="/materiel" element={<Materiel />} />
            <Route path="/prestation" element={<Prestation />} />
            <Route path="/tarif" element={<Tarif />} />
            <Route path="/" element={<Navigate to="/gestionnaire" replace />} />
            <Route path="*" element={<Navigate to="/gestionnaire" replace />} />
          </Routes>
        </main>
      </div>
    </TableProvider>
  );
}
export default App;
