import uvicorn
import os, json
import time as time_module
import logging
from fastapi import Depends, FastAPI, HTTPException, Request, status, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from pydantic_classes import *
from sql_alchemy import *

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

############################################
#
#   Initialize the database
#
############################################

def init_db():
    SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/Class_Diagram.db")
    # Ensure local SQLite directory exists (safe no-op for other DBs)
    os.makedirs("data", exist_ok=True)
    engine = create_engine(
        SQLALCHEMY_DATABASE_URL,
        connect_args={"check_same_thread": False},
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=False
    )
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    return SessionLocal

app = FastAPI(
    title="Class_Diagram API",
    description="Auto-generated REST API with full CRUD operations, relationship management, and advanced features",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "System", "description": "System health and statistics"},
        {"name": "Indisponibilite", "description": "Operations for Indisponibilite entities"},
        {"name": "Indisponibilite Relationships", "description": "Manage Indisponibilite relationships"},
        {"name": "Indisponibilite Methods", "description": "Execute Indisponibilite methods"},
        {"name": "Tarif", "description": "Operations for Tarif entities"},
        {"name": "Tarif Relationships", "description": "Manage Tarif relationships"},
        {"name": "Tarif Methods", "description": "Execute Tarif methods"},
        {"name": "Supplement", "description": "Operations for Supplement entities"},
        {"name": "Supplement Relationships", "description": "Manage Supplement relationships"},
        {"name": "Supplement Methods", "description": "Execute Supplement methods"},
        {"name": "Materiel", "description": "Operations for Materiel entities"},
        {"name": "Materiel Methods", "description": "Execute Materiel methods"},
        {"name": "Prestation", "description": "Operations for Prestation entities"},
        {"name": "Prestation Methods", "description": "Execute Prestation methods"},
        {"name": "Reservation", "description": "Operations for Reservation entities"},
        {"name": "Reservation Relationships", "description": "Manage Reservation relationships"},
        {"name": "Reservation Methods", "description": "Execute Reservation methods"},
        {"name": "Evenement", "description": "Operations for Evenement entities"},
        {"name": "Evenement Relationships", "description": "Manage Evenement relationships"},
        {"name": "Element", "description": "Operations for Element entities"},
        {"name": "Element Relationships", "description": "Manage Element relationships"},
        {"name": "Element Methods", "description": "Execute Element methods"},
        {"name": "CentreCongres", "description": "Operations for CentreCongres entities"},
        {"name": "CentreCongres Relationships", "description": "Manage CentreCongres relationships"},
        {"name": "CentreCongres Methods", "description": "Execute CentreCongres methods"},
        {"name": "Gestionnaire", "description": "Operations for Gestionnaire entities"},
        {"name": "Gestionnaire Relationships", "description": "Manage Gestionnaire relationships"},
        {"name": "Gestionnaire Methods", "description": "Execute Gestionnaire methods"},
    ]
)

# Enable CORS for all origins (for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or restrict to ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

############################################
#
#   Middleware
#
############################################

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests and responses."""
    logger.info(f"Incoming request: {request.method} {request.url.path}")
    response = await call_next(request)
    logger.info(f"Response status: {response.status_code}")
    return response

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add processing time header to all responses."""
    start_time = time_module.time()
    response = await call_next(request)
    process_time = time_module.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

############################################
#
#   Exception Handlers
#
############################################

# Global exception handlers
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    """Handle ValueError exceptions."""
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "error": "Bad Request",
            "message": str(exc),
            "detail": "Invalid input data provided"
        }
    )


@app.exception_handler(IntegrityError)
async def integrity_error_handler(request: Request, exc: IntegrityError):
    """Handle database integrity errors."""
    logger.error(f"Database integrity error: {exc}")

    # Extract more detailed error information
    error_detail = str(exc.orig) if hasattr(exc, 'orig') else str(exc)

    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content={
            "error": "Conflict",
            "message": "Data conflict occurred",
            "detail": error_detail
        }
    )


@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_error_handler(request: Request, exc: SQLAlchemyError):
    """Handle general SQLAlchemy errors."""
    logger.error(f"Database error: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal Server Error",
            "message": "Database operation failed",
            "detail": "An internal database error occurred"
        }
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions with consistent format."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail if isinstance(exc.detail, str) else "HTTP Error",
            "message": exc.detail,
            "detail": f"HTTP {exc.status_code} error occurred"
        }
    )

# Initialize database session
SessionLocal = init_db()
# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        logger.error("Database session rollback due to exception")
        raise
    finally:
        db.close()

############################################
#
#   Global API endpoints
#
############################################

@app.get("/", tags=["System"])
def root():
    """Root endpoint - API information"""
    return {
        "name": "Class_Diagram API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health", tags=["System"])
def health_check():
    """Health check endpoint for monitoring"""
    from datetime import datetime
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "database": "connected"
    }


@app.get("/statistics", tags=["System"])
def get_statistics(database: Session = Depends(get_db)):
    """Get database statistics for all entities"""
    stats = {}
    stats["indisponibilite_count"] = database.query(Indisponibilite).count()
    stats["tarif_count"] = database.query(Tarif).count()
    stats["supplement_count"] = database.query(Supplement).count()
    stats["materiel_count"] = database.query(Materiel).count()
    stats["prestation_count"] = database.query(Prestation).count()
    stats["reservation_count"] = database.query(Reservation).count()
    stats["evenement_count"] = database.query(Evenement).count()
    stats["element_count"] = database.query(Element).count()
    stats["centrecongres_count"] = database.query(CentreCongres).count()
    stats["gestionnaire_count"] = database.query(Gestionnaire).count()
    stats["total_entities"] = sum(stats.values())
    return stats


############################################
#
#   BESSER Action Language standard lib
#
############################################


async def BAL_size(sequence:list) -> int:
    return len(sequence)

async def BAL_is_empty(sequence:list) -> bool:
    return len(sequence) == 0

async def BAL_add(sequence:list, elem) -> None:
    sequence.append(elem)

async def BAL_remove(sequence:list, elem) -> None:
    sequence.remove(elem)

async def BAL_contains(sequence:list, elem) -> bool:
    return elem in sequence

async def BAL_filter(sequence:list, predicate) -> list:
    return [elem for elem in sequence if predicate(elem)]

async def BAL_forall(sequence:list, predicate) -> bool:
    for elem in sequence:
        if not predicate(elem):
            return False
    return True

async def BAL_exists(sequence:list, predicate) -> bool:
    for elem in sequence:
        if predicate(elem):
            return True
    return False

async def BAL_one(sequence:list, predicate) -> bool:
    found = False
    for elem in sequence:
        if predicate(elem):
            if found:
                return False
            found = True
    return found

async def BAL_is_unique(sequence:list, mapping) -> bool:
    mapped = [mapping(elem) for elem in sequence]
    return len(set(mapped)) == len(mapped)

async def BAL_map(sequence:list, mapping) -> list:
    return [mapping(elem) for elem in sequence]

async def BAL_reduce(sequence:list, reduce_fn, aggregator) -> any:
    for elem in sequence:
        aggregator = reduce_fn(aggregator, elem)
    return aggregator


############################################
#
#   Indisponibilite functions
#
############################################

@app.get("/indisponibilite/", response_model=None, tags=["Indisponibilite"])
def get_all_indisponibilite(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Indisponibilite)
        query = query.options(joinedload(Indisponibilite.element_3))
        indisponibilite_list = query.all()

        # Serialize with relationships included
        result = []
        for indisponibilite_item in indisponibilite_list:
            item_dict = indisponibilite_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if indisponibilite_item.element_3:
                related_obj = indisponibilite_item.element_3
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['element_3'] = related_dict
            else:
                item_dict['element_3'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Indisponibilite).all()


@app.get("/indisponibilite/count/", response_model=None, tags=["Indisponibilite"])
def get_count_indisponibilite(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Indisponibilite entities"""
    count = database.query(Indisponibilite).count()
    return {"count": count}


@app.get("/indisponibilite/paginated/", response_model=None, tags=["Indisponibilite"])
def get_paginated_indisponibilite(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Indisponibilite entities"""
    total = database.query(Indisponibilite).count()
    indisponibilite_list = database.query(Indisponibilite).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": indisponibilite_list
    }


@app.get("/indisponibilite/search/", response_model=None, tags=["Indisponibilite"])
def search_indisponibilite(
    database: Session = Depends(get_db)
) -> list:
    """Search Indisponibilite entities by attributes"""
    query = database.query(Indisponibilite)


    results = query.all()
    return results


@app.get("/indisponibilite/{indisponibilite_id}/", response_model=None, tags=["Indisponibilite"])
async def get_indisponibilite(indisponibilite_id: int, database: Session = Depends(get_db)) -> Indisponibilite:
    db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
    if db_indisponibilite is None:
        raise HTTPException(status_code=404, detail="Indisponibilite not found")

    response_data = {
        "indisponibilite": db_indisponibilite,
}
    return response_data



@app.post("/indisponibilite/", response_model=None, tags=["Indisponibilite"])
async def create_indisponibilite(indisponibilite_data: IndisponibiliteCreate, database: Session = Depends(get_db)) -> Indisponibilite:

    if indisponibilite_data.element_3 is not None:
        db_element_3 = database.query(Element).filter(Element.id == indisponibilite_data.element_3).first()
        if not db_element_3:
            raise HTTPException(status_code=400, detail="Element not found")
    else:
        raise HTTPException(status_code=400, detail="Element ID is required")

    db_indisponibilite = Indisponibilite(
        dateFin=indisponibilite_data.dateFin,        motif=indisponibilite_data.motif,        dateDebut=indisponibilite_data.dateDebut,        element_3_id=indisponibilite_data.element_3        )

    database.add(db_indisponibilite)
    database.commit()
    database.refresh(db_indisponibilite)




    return db_indisponibilite


@app.post("/indisponibilite/bulk/", response_model=None, tags=["Indisponibilite"])
async def bulk_create_indisponibilite(items: list[IndisponibiliteCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Indisponibilite entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.element_3:
                raise ValueError("Element ID is required")

            db_indisponibilite = Indisponibilite(
                dateFin=item_data.dateFin,                motif=item_data.motif,                dateDebut=item_data.dateDebut,                element_3_id=item_data.element_3            )
            database.add(db_indisponibilite)
            database.flush()  # Get ID without committing
            created_items.append(db_indisponibilite.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Indisponibilite entities"
    }


@app.delete("/indisponibilite/bulk/", response_model=None, tags=["Indisponibilite"])
async def bulk_delete_indisponibilite(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Indisponibilite entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == item_id).first()
        if db_indisponibilite:
            database.delete(db_indisponibilite)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Indisponibilite entities"
    }

@app.put("/indisponibilite/{indisponibilite_id}/", response_model=None, tags=["Indisponibilite"])
async def update_indisponibilite(indisponibilite_id: int, indisponibilite_data: IndisponibiliteCreate, database: Session = Depends(get_db)) -> Indisponibilite:
    db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
    if db_indisponibilite is None:
        raise HTTPException(status_code=404, detail="Indisponibilite not found")

    setattr(db_indisponibilite, 'dateFin', indisponibilite_data.dateFin)
    setattr(db_indisponibilite, 'motif', indisponibilite_data.motif)
    setattr(db_indisponibilite, 'dateDebut', indisponibilite_data.dateDebut)
    if indisponibilite_data.element_3 is not None:
        db_element_3 = database.query(Element).filter(Element.id == indisponibilite_data.element_3).first()
        if not db_element_3:
            raise HTTPException(status_code=400, detail="Element not found")
        setattr(db_indisponibilite, 'element_3_id', indisponibilite_data.element_3)
    database.commit()
    database.refresh(db_indisponibilite)

    return db_indisponibilite


@app.delete("/indisponibilite/{indisponibilite_id}/", response_model=None, tags=["Indisponibilite"])
async def delete_indisponibilite(indisponibilite_id: int, database: Session = Depends(get_db)):
    db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
    if db_indisponibilite is None:
        raise HTTPException(status_code=404, detail="Indisponibilite not found")
    database.delete(db_indisponibilite)
    database.commit()
    return db_indisponibilite



############################################
#   Indisponibilite Method Endpoints
############################################




@app.post("/indisponibilite/methods/chevauche/", response_model=None, tags=["Indisponibilite Methods"])
async def indisponibilite_chevauche(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the chevauche class method on Indisponibilite.
    This method operates on all Indisponibilite entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebut: date    - dateFin: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebut = params.get('dateDebut')
        dateFin = params.get('dateFin')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Indisponibilite",
            "method": "chevauche",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Tarif functions
#
############################################

@app.get("/tarif/", response_model=None, tags=["Tarif"])
def get_all_tarif(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Tarif)
        tarif_list = query.all()

        # Serialize with relationships included
        result = []
        for tarif_item in tarif_list:
            item_dict = tarif_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            element_list = database.query(Element).filter(Element.tarif_id == tarif_item.id).all()
            item_dict['element_2'] = []
            for element_obj in element_list:
                element_dict = element_obj.__dict__.copy()
                element_dict.pop('_sa_instance_state', None)
                item_dict['element_2'].append(element_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Tarif).all()


@app.get("/tarif/count/", response_model=None, tags=["Tarif"])
def get_count_tarif(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Tarif entities"""
    count = database.query(Tarif).count()
    return {"count": count}


@app.get("/tarif/paginated/", response_model=None, tags=["Tarif"])
def get_paginated_tarif(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Tarif entities"""
    total = database.query(Tarif).count()
    tarif_list = database.query(Tarif).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": tarif_list
        }

    result = []
    for tarif_item in tarif_list:
        element_2_ids = database.query(Element.id).filter(Element.tarif_id == tarif_item.id).all()
        item_data = {
            "tarif": tarif_item,
            "element_2_ids": [x[0] for x in element_2_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/tarif/search/", response_model=None, tags=["Tarif"])
def search_tarif(
    database: Session = Depends(get_db)
) -> list:
    """Search Tarif entities by attributes"""
    query = database.query(Tarif)


    results = query.all()
    return results


@app.get("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def get_tarif(tarif_id: int, database: Session = Depends(get_db)) -> Tarif:
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")

    element_2_ids = database.query(Element.id).filter(Element.tarif_id == db_tarif.id).all()
    response_data = {
        "tarif": db_tarif,
        "element_2_ids": [x[0] for x in element_2_ids]}
    return response_data



@app.post("/tarif/", response_model=None, tags=["Tarif"])
async def create_tarif(tarif_data: TarifCreate, database: Session = Depends(get_db)) -> Tarif:


    db_tarif = Tarif(
        saison=tarif_data.saison.value,        prix=tarif_data.prix        )

    database.add(db_tarif)
    database.commit()
    database.refresh(db_tarif)

    if tarif_data.element_2:
        # Validate that all Element IDs exist
        for element_id in tarif_data.element_2:
            db_element = database.query(Element).filter(Element.id == element_id).first()
            if not db_element:
                raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

        # Update the related entities with the new foreign key
        database.query(Element).filter(Element.id.in_(tarif_data.element_2)).update(
            {Element.tarif_id: db_tarif.id}, synchronize_session=False
        )
        database.commit()



    element_2_ids = database.query(Element.id).filter(Element.tarif_id == db_tarif.id).all()
    response_data = {
        "tarif": db_tarif,
        "element_2_ids": [x[0] for x in element_2_ids]    }
    return response_data


@app.post("/tarif/bulk/", response_model=None, tags=["Tarif"])
async def bulk_create_tarif(items: list[TarifCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Tarif entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_tarif = Tarif(
                saison=item_data.saison.value,                prix=item_data.prix            )
            database.add(db_tarif)
            database.flush()  # Get ID without committing
            created_items.append(db_tarif.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Tarif entities"
    }


@app.delete("/tarif/bulk/", response_model=None, tags=["Tarif"])
async def bulk_delete_tarif(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Tarif entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_tarif = database.query(Tarif).filter(Tarif.id == item_id).first()
        if db_tarif:
            database.delete(db_tarif)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Tarif entities"
    }

@app.put("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def update_tarif(tarif_id: int, tarif_data: TarifCreate, database: Session = Depends(get_db)) -> Tarif:
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")

    setattr(db_tarif, 'saison', tarif_data.saison.value)
    setattr(db_tarif, 'prix', tarif_data.prix)
    if tarif_data.element_2 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Element).filter(Element.tarif_id == db_tarif.id).update(
            {Element.tarif_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if tarif_data.element_2:
            # Validate that all IDs exist
            for element_id in tarif_data.element_2:
                db_element = database.query(Element).filter(Element.id == element_id).first()
                if not db_element:
                    raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

            # Update the related entities with the new foreign key
            database.query(Element).filter(Element.id.in_(tarif_data.element_2)).update(
                {Element.tarif_id: db_tarif.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_tarif)

    element_2_ids = database.query(Element.id).filter(Element.tarif_id == db_tarif.id).all()
    response_data = {
        "tarif": db_tarif,
        "element_2_ids": [x[0] for x in element_2_ids]    }
    return response_data


@app.delete("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def delete_tarif(tarif_id: int, database: Session = Depends(get_db)):
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")
    database.delete(db_tarif)
    database.commit()
    return db_tarif



############################################
#   Tarif Method Endpoints
############################################




@app.post("/tarif/methods/setPrix/", response_model=None, tags=["Tarif Methods"])
async def tarif_setPrix(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the setPrix class method on Tarif.
    This method operates on all Tarif entities or performs class-level operations.

    Parameters (pass as JSON body):
    - prix: float    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        prix = params.get('prix')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Tarif",
            "method": "setPrix",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/tarif/methods/getPrix/", response_model=None, tags=["Tarif Methods"])
async def tarif_getPrix(
    database: Session = Depends(get_db)
):
    """
    Execute the getPrix class method on Tarif.
    This method operates on all Tarif entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Tarif",
            "method": "getPrix",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Supplement functions
#
############################################

@app.get("/supplement/", response_model=None, tags=["Supplement"])
def get_all_supplement(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Supplement)
        query = query.options(joinedload(Supplement.reservation_1))
        supplement_list = query.all()

        # Serialize with relationships included
        result = []
        for supplement_item in supplement_list:
            item_dict = supplement_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if supplement_item.reservation_1:
                related_obj = supplement_item.reservation_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_1'] = related_dict
            else:
                item_dict['reservation_1'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Supplement).all()


@app.get("/supplement/count/", response_model=None, tags=["Supplement"])
def get_count_supplement(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Supplement entities"""
    count = database.query(Supplement).count()
    return {"count": count}


@app.get("/supplement/paginated/", response_model=None, tags=["Supplement"])
def get_paginated_supplement(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Supplement entities"""
    total = database.query(Supplement).count()
    supplement_list = database.query(Supplement).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": supplement_list
    }


@app.get("/supplement/search/", response_model=None, tags=["Supplement"])
def search_supplement(
    database: Session = Depends(get_db)
) -> list:
    """Search Supplement entities by attributes"""
    query = database.query(Supplement)


    results = query.all()
    return results


@app.get("/supplement/{supplement_id}/", response_model=None, tags=["Supplement"])
async def get_supplement(supplement_id: int, database: Session = Depends(get_db)) -> Supplement:
    db_supplement = database.query(Supplement).filter(Supplement.id == supplement_id).first()
    if db_supplement is None:
        raise HTTPException(status_code=404, detail="Supplement not found")

    response_data = {
        "supplement": db_supplement,
}
    return response_data



@app.post("/supplement/", response_model=None, tags=["Supplement"])
async def create_supplement(supplement_data: SupplementCreate, database: Session = Depends(get_db)) -> Supplement:

    if supplement_data.reservation_1 is not None:
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == supplement_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
    else:
        raise HTTPException(status_code=400, detail="Reservation ID is required")

    db_supplement = Supplement(
        nom=supplement_data.nom,        prix=supplement_data.prix,        quantiteMax=supplement_data.quantiteMax,        reservation_1_id=supplement_data.reservation_1        )

    database.add(db_supplement)
    database.commit()
    database.refresh(db_supplement)




    return db_supplement


@app.post("/supplement/bulk/", response_model=None, tags=["Supplement"])
async def bulk_create_supplement(items: list[SupplementCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Supplement entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.reservation_1:
                raise ValueError("Reservation ID is required")

            db_supplement = Supplement(
                nom=item_data.nom,                prix=item_data.prix,                quantiteMax=item_data.quantiteMax,                reservation_1_id=item_data.reservation_1            )
            database.add(db_supplement)
            database.flush()  # Get ID without committing
            created_items.append(db_supplement.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Supplement entities"
    }


@app.delete("/supplement/bulk/", response_model=None, tags=["Supplement"])
async def bulk_delete_supplement(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Supplement entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_supplement = database.query(Supplement).filter(Supplement.id == item_id).first()
        if db_supplement:
            database.delete(db_supplement)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Supplement entities"
    }

@app.put("/supplement/{supplement_id}/", response_model=None, tags=["Supplement"])
async def update_supplement(supplement_id: int, supplement_data: SupplementCreate, database: Session = Depends(get_db)) -> Supplement:
    db_supplement = database.query(Supplement).filter(Supplement.id == supplement_id).first()
    if db_supplement is None:
        raise HTTPException(status_code=404, detail="Supplement not found")

    setattr(db_supplement, 'nom', supplement_data.nom)
    setattr(db_supplement, 'prix', supplement_data.prix)
    setattr(db_supplement, 'quantiteMax', supplement_data.quantiteMax)
    if supplement_data.reservation_1 is not None:
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == supplement_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
        setattr(db_supplement, 'reservation_1_id', supplement_data.reservation_1)
    database.commit()
    database.refresh(db_supplement)

    return db_supplement


@app.delete("/supplement/{supplement_id}/", response_model=None, tags=["Supplement"])
async def delete_supplement(supplement_id: int, database: Session = Depends(get_db)):
    db_supplement = database.query(Supplement).filter(Supplement.id == supplement_id).first()
    if db_supplement is None:
        raise HTTPException(status_code=404, detail="Supplement not found")
    database.delete(db_supplement)
    database.commit()
    return db_supplement



############################################
#   Supplement Method Endpoints
############################################




@app.post("/supplement/methods/getPrix/", response_model=None, tags=["Supplement Methods"])
async def supplement_getPrix(
    database: Session = Depends(get_db)
):
    """
    Execute the getPrix class method on Supplement.
    This method operates on all Supplement entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Supplement",
            "method": "getPrix",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Materiel functions
#
############################################

@app.get("/materiel/", response_model=None, tags=["Materiel"])
def get_all_materiel(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Materiel)
        query = query.options(joinedload(Materiel.reservation_1))
        materiel_list = query.all()

        # Serialize with relationships included
        result = []
        for materiel_item in materiel_list:
            item_dict = materiel_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if materiel_item.reservation_1:
                related_obj = materiel_item.reservation_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_1'] = related_dict
            else:
                item_dict['reservation_1'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Materiel).all()


@app.get("/materiel/count/", response_model=None, tags=["Materiel"])
def get_count_materiel(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Materiel entities"""
    count = database.query(Materiel).count()
    return {"count": count}


@app.get("/materiel/paginated/", response_model=None, tags=["Materiel"])
def get_paginated_materiel(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Materiel entities"""
    total = database.query(Materiel).count()
    materiel_list = database.query(Materiel).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": materiel_list
    }


@app.get("/materiel/search/", response_model=None, tags=["Materiel"])
def search_materiel(
    database: Session = Depends(get_db)
) -> list:
    """Search Materiel entities by attributes"""
    query = database.query(Materiel)


    results = query.all()
    return results


@app.get("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def get_materiel(materiel_id: int, database: Session = Depends(get_db)) -> Materiel:
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    response_data = {
        "materiel": db_materiel,
}
    return response_data



@app.post("/materiel/", response_model=None, tags=["Materiel"])
async def create_materiel(materiel_data: MaterielCreate, database: Session = Depends(get_db)) -> Materiel:

    if materiel_data.reservation_1 is not None:
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == materiel_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
    else:
        raise HTTPException(status_code=400, detail="Reservation ID is required")

    db_materiel = Materiel(
        nom=materiel_data.nom,        prix=materiel_data.prix,        quantiteMax=materiel_data.quantiteMax,        quantiteDispo=materiel_data.quantiteDispo,        reservation_1_id=materiel_data.reservation_1        )

    database.add(db_materiel)
    database.commit()
    database.refresh(db_materiel)




    return db_materiel


@app.post("/materiel/bulk/", response_model=None, tags=["Materiel"])
async def bulk_create_materiel(items: list[MaterielCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Materiel entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.reservation_1:
                raise ValueError("Reservation ID is required")

            db_materiel = Materiel(
                nom=item_data.nom,                prix=item_data.prix,                quantiteMax=item_data.quantiteMax,                quantiteDispo=item_data.quantiteDispo,                reservation_1_id=item_data.reservation_1            )
            database.add(db_materiel)
            database.flush()  # Get ID without committing
            created_items.append(db_materiel.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Materiel entities"
    }


@app.delete("/materiel/bulk/", response_model=None, tags=["Materiel"])
async def bulk_delete_materiel(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Materiel entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_materiel = database.query(Materiel).filter(Materiel.id == item_id).first()
        if db_materiel:
            database.delete(db_materiel)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Materiel entities"
    }

@app.put("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def update_materiel(materiel_id: int, materiel_data: MaterielCreate, database: Session = Depends(get_db)) -> Materiel:
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    setattr(db_materiel, 'quantiteDispo', materiel_data.quantiteDispo)
    database.commit()
    database.refresh(db_materiel)

    return db_materiel


@app.delete("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def delete_materiel(materiel_id: int, database: Session = Depends(get_db)):
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")
    database.delete(db_materiel)
    database.commit()
    return db_materiel



############################################
#   Materiel Method Endpoints
############################################




@app.post("/materiel/methods/estDisponible/", response_model=None, tags=["Materiel Methods"])
async def materiel_estDisponible(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the estDisponible class method on Materiel.
    This method operates on all Materiel entities or performs class-level operations.

    Parameters (pass as JSON body):
    - quantite: int    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        quantite = params.get('quantite')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Materiel",
            "method": "estDisponible",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Prestation functions
#
############################################

@app.get("/prestation/", response_model=None, tags=["Prestation"])
def get_all_prestation(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Prestation)
        query = query.options(joinedload(Prestation.reservation_1))
        prestation_list = query.all()

        # Serialize with relationships included
        result = []
        for prestation_item in prestation_list:
            item_dict = prestation_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if prestation_item.reservation_1:
                related_obj = prestation_item.reservation_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_1'] = related_dict
            else:
                item_dict['reservation_1'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Prestation).all()


@app.get("/prestation/count/", response_model=None, tags=["Prestation"])
def get_count_prestation(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Prestation entities"""
    count = database.query(Prestation).count()
    return {"count": count}


@app.get("/prestation/paginated/", response_model=None, tags=["Prestation"])
def get_paginated_prestation(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Prestation entities"""
    total = database.query(Prestation).count()
    prestation_list = database.query(Prestation).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": prestation_list
    }


@app.get("/prestation/search/", response_model=None, tags=["Prestation"])
def search_prestation(
    database: Session = Depends(get_db)
) -> list:
    """Search Prestation entities by attributes"""
    query = database.query(Prestation)


    results = query.all()
    return results


@app.get("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def get_prestation(prestation_id: int, database: Session = Depends(get_db)) -> Prestation:
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    response_data = {
        "prestation": db_prestation,
}
    return response_data



@app.post("/prestation/", response_model=None, tags=["Prestation"])
async def create_prestation(prestation_data: PrestationCreate, database: Session = Depends(get_db)) -> Prestation:

    if prestation_data.reservation_1 is not None:
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == prestation_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
    else:
        raise HTTPException(status_code=400, detail="Reservation ID is required")

    db_prestation = Prestation(
        nom=prestation_data.nom,        prix=prestation_data.prix,        quantiteMax=prestation_data.quantiteMax,        typePrestation=prestation_data.typePrestation,        reservation_1_id=prestation_data.reservation_1        )

    database.add(db_prestation)
    database.commit()
    database.refresh(db_prestation)




    return db_prestation


@app.post("/prestation/bulk/", response_model=None, tags=["Prestation"])
async def bulk_create_prestation(items: list[PrestationCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Prestation entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.reservation_1:
                raise ValueError("Reservation ID is required")

            db_prestation = Prestation(
                nom=item_data.nom,                prix=item_data.prix,                quantiteMax=item_data.quantiteMax,                typePrestation=item_data.typePrestation,                reservation_1_id=item_data.reservation_1            )
            database.add(db_prestation)
            database.flush()  # Get ID without committing
            created_items.append(db_prestation.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Prestation entities"
    }


@app.delete("/prestation/bulk/", response_model=None, tags=["Prestation"])
async def bulk_delete_prestation(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Prestation entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_prestation = database.query(Prestation).filter(Prestation.id == item_id).first()
        if db_prestation:
            database.delete(db_prestation)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Prestation entities"
    }

@app.put("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def update_prestation(prestation_id: int, prestation_data: PrestationCreate, database: Session = Depends(get_db)) -> Prestation:
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    setattr(db_prestation, 'typePrestation', prestation_data.typePrestation)
    database.commit()
    database.refresh(db_prestation)

    return db_prestation


@app.delete("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def delete_prestation(prestation_id: int, database: Session = Depends(get_db)):
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")
    database.delete(db_prestation)
    database.commit()
    return db_prestation



############################################
#   Prestation Method Endpoints
############################################




@app.post("/prestation/methods/calculerCout/", response_model=None, tags=["Prestation Methods"])
async def prestation_calculerCout(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the calculerCout class method on Prestation.
    This method operates on all Prestation entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nbParticipants: int    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nbParticipants = params.get('nbParticipants')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Prestation",
            "method": "calculerCout",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Reservation functions
#
############################################

@app.get("/reservation/", response_model=None, tags=["Reservation"])
def get_all_reservation(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Reservation)
        query = query.options(joinedload(Reservation.evenement))
        query = query.options(joinedload(Reservation.element_1))
        reservation_list = query.all()

        # Serialize with relationships included
        result = []
        for reservation_item in reservation_list:
            item_dict = reservation_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if reservation_item.evenement:
                related_obj = reservation_item.evenement
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['evenement'] = related_dict
            else:
                item_dict['evenement'] = None
            if reservation_item.element_1:
                related_obj = reservation_item.element_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['element_1'] = related_dict
            else:
                item_dict['element_1'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            supplement_list = database.query(Supplement).filter(Supplement.reservation_1_id == reservation_item.id).all()
            item_dict['supplement'] = []
            for supplement_obj in supplement_list:
                supplement_dict = supplement_obj.__dict__.copy()
                supplement_dict.pop('_sa_instance_state', None)
                item_dict['supplement'].append(supplement_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Reservation).all()


@app.get("/reservation/count/", response_model=None, tags=["Reservation"])
def get_count_reservation(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Reservation entities"""
    count = database.query(Reservation).count()
    return {"count": count}


@app.get("/reservation/paginated/", response_model=None, tags=["Reservation"])
def get_paginated_reservation(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Reservation entities"""
    total = database.query(Reservation).count()
    reservation_list = database.query(Reservation).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": reservation_list
        }

    result = []
    for reservation_item in reservation_list:
        supplement_ids = database.query(Supplement.id).filter(Supplement.reservation_1_id == reservation_item.id).all()
        item_data = {
            "reservation": reservation_item,
            "supplement_ids": [x[0] for x in supplement_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/reservation/search/", response_model=None, tags=["Reservation"])
def search_reservation(
    database: Session = Depends(get_db)
) -> list:
    """Search Reservation entities by attributes"""
    query = database.query(Reservation)


    results = query.all()
    return results


@app.get("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def get_reservation(reservation_id: int, database: Session = Depends(get_db)) -> Reservation:
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    supplement_ids = database.query(Supplement.id).filter(Supplement.reservation_1_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "supplement_ids": [x[0] for x in supplement_ids]}
    return response_data



@app.post("/reservation/", response_model=None, tags=["Reservation"])
async def create_reservation(reservation_data: ReservationCreate, database: Session = Depends(get_db)) -> Reservation:

    if reservation_data.evenement is not None:
        db_evenement = database.query(Evenement).filter(Evenement.id == reservation_data.evenement).first()
        if not db_evenement:
            raise HTTPException(status_code=400, detail="Evenement not found")
    else:
        raise HTTPException(status_code=400, detail="Evenement ID is required")
    if reservation_data.element_1 is not None:
        db_element_1 = database.query(Element).filter(Element.id == reservation_data.element_1).first()
        if not db_element_1:
            raise HTTPException(status_code=400, detail="Element not found")
    else:
        raise HTTPException(status_code=400, detail="Element ID is required")

    db_reservation = Reservation(
        dateFin=reservation_data.dateFin,        dateLimiteconfirmation=reservation_data.dateLimiteconfirmation,        statut=reservation_data.statut.value,        dateDeb=reservation_data.dateDeb,        evenement_id=reservation_data.evenement,        element_1_id=reservation_data.element_1        )

    database.add(db_reservation)
    database.commit()
    database.refresh(db_reservation)

    if reservation_data.supplement:
        # Validate that all Supplement IDs exist
        for supplement_id in reservation_data.supplement:
            db_supplement = database.query(Supplement).filter(Supplement.id == supplement_id).first()
            if not db_supplement:
                raise HTTPException(status_code=400, detail=f"Supplement with id {supplement_id} not found")

        # Update the related entities with the new foreign key
        database.query(Supplement).filter(Supplement.id.in_(reservation_data.supplement)).update(
            {Supplement.reservation_1_id: db_reservation.id}, synchronize_session=False
        )
        database.commit()



    supplement_ids = database.query(Supplement.id).filter(Supplement.reservation_1_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "supplement_ids": [x[0] for x in supplement_ids]    }
    return response_data


@app.post("/reservation/bulk/", response_model=None, tags=["Reservation"])
async def bulk_create_reservation(items: list[ReservationCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Reservation entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.evenement:
                raise ValueError("Evenement ID is required")
            if not item_data.element_1:
                raise ValueError("Element ID is required")

            db_reservation = Reservation(
                dateFin=item_data.dateFin,                dateLimiteconfirmation=item_data.dateLimiteconfirmation,                statut=item_data.statut.value,                dateDeb=item_data.dateDeb,                evenement_id=item_data.evenement,                element_1_id=item_data.element_1            )
            database.add(db_reservation)
            database.flush()  # Get ID without committing
            created_items.append(db_reservation.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Reservation entities"
    }


@app.delete("/reservation/bulk/", response_model=None, tags=["Reservation"])
async def bulk_delete_reservation(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Reservation entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_reservation = database.query(Reservation).filter(Reservation.id == item_id).first()
        if db_reservation:
            database.delete(db_reservation)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Reservation entities"
    }

@app.put("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def update_reservation(reservation_id: int, reservation_data: ReservationCreate, database: Session = Depends(get_db)) -> Reservation:
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    setattr(db_reservation, 'dateFin', reservation_data.dateFin)
    setattr(db_reservation, 'dateLimiteconfirmation', reservation_data.dateLimiteconfirmation)
    setattr(db_reservation, 'statut', reservation_data.statut.value)
    setattr(db_reservation, 'dateDeb', reservation_data.dateDeb)
    if reservation_data.evenement is not None:
        db_evenement = database.query(Evenement).filter(Evenement.id == reservation_data.evenement).first()
        if not db_evenement:
            raise HTTPException(status_code=400, detail="Evenement not found")
        setattr(db_reservation, 'evenement_id', reservation_data.evenement)
    if reservation_data.element_1 is not None:
        db_element_1 = database.query(Element).filter(Element.id == reservation_data.element_1).first()
        if not db_element_1:
            raise HTTPException(status_code=400, detail="Element not found")
        setattr(db_reservation, 'element_1_id', reservation_data.element_1)
    if reservation_data.supplement is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Supplement).filter(Supplement.reservation_1_id == db_reservation.id).update(
            {Supplement.reservation_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if reservation_data.supplement:
            # Validate that all IDs exist
            for supplement_id in reservation_data.supplement:
                db_supplement = database.query(Supplement).filter(Supplement.id == supplement_id).first()
                if not db_supplement:
                    raise HTTPException(status_code=400, detail=f"Supplement with id {supplement_id} not found")

            # Update the related entities with the new foreign key
            database.query(Supplement).filter(Supplement.id.in_(reservation_data.supplement)).update(
                {Supplement.reservation_1_id: db_reservation.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_reservation)

    supplement_ids = database.query(Supplement.id).filter(Supplement.reservation_1_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "supplement_ids": [x[0] for x in supplement_ids]    }
    return response_data


@app.delete("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def delete_reservation(reservation_id: int, database: Session = Depends(get_db)):
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")
    database.delete(db_reservation)
    database.commit()
    return db_reservation



############################################
#   Reservation Method Endpoints
############################################




@app.post("/reservation/methods/calculerCoutTotal/", response_model=None, tags=["Reservation Methods"])
async def reservation_calculerCoutTotal(
    database: Session = Depends(get_db)
):
    """
    Execute the calculerCoutTotal class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "calculerCoutTotal",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/annuler/", response_model=None, tags=["Reservation Methods"])
async def reservation_annuler(
    database: Session = Depends(get_db)
):
    """
    Execute the annuler class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "annuler",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/ajouterSupplement/", response_model=None, tags=["Reservation Methods"])
async def reservation_ajouterSupplement(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the ajouterSupplement class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.

    Parameters (pass as JSON body):
    - s: Supplement    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        s = await get_supplement(params.get('s'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "ajouterSupplement",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/confirmer/", response_model=None, tags=["Reservation Methods"])
async def reservation_confirmer(
    database: Session = Depends(get_db)
):
    """
    Execute the confirmer class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "confirmer",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/modifier/", response_model=None, tags=["Reservation Methods"])
async def reservation_modifier(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the modifier class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebut: date    - dateFin: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebut = params.get('dateDebut')
        dateFin = params.get('dateFin')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "modifier",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/retirerSupplement/", response_model=None, tags=["Reservation Methods"])
async def reservation_retirerSupplement(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the retirerSupplement class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.

    Parameters (pass as JSON body):
    - s: Supplement    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        s = await get_supplement(params.get('s'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "retirerSupplement",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Evenement functions
#
############################################

@app.get("/evenement/", response_model=None, tags=["Evenement"])
def get_all_evenement(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Evenement)
        evenement_list = query.all()

        # Serialize with relationships included
        result = []
        for evenement_item in evenement_list:
            item_dict = evenement_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            reservation_list = database.query(Reservation).filter(Reservation.evenement_id == evenement_item.id).all()
            item_dict['reservation'] = []
            for reservation_obj in reservation_list:
                reservation_dict = reservation_obj.__dict__.copy()
                reservation_dict.pop('_sa_instance_state', None)
                item_dict['reservation'].append(reservation_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Evenement).all()


@app.get("/evenement/count/", response_model=None, tags=["Evenement"])
def get_count_evenement(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Evenement entities"""
    count = database.query(Evenement).count()
    return {"count": count}


@app.get("/evenement/paginated/", response_model=None, tags=["Evenement"])
def get_paginated_evenement(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Evenement entities"""
    total = database.query(Evenement).count()
    evenement_list = database.query(Evenement).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": evenement_list
        }

    result = []
    for evenement_item in evenement_list:
        reservation_ids = database.query(Reservation.id).filter(Reservation.evenement_id == evenement_item.id).all()
        item_data = {
            "evenement": evenement_item,
            "reservation_ids": [x[0] for x in reservation_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/evenement/search/", response_model=None, tags=["Evenement"])
def search_evenement(
    database: Session = Depends(get_db)
) -> list:
    """Search Evenement entities by attributes"""
    query = database.query(Evenement)


    results = query.all()
    return results


@app.get("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def get_evenement(evenement_id: int, database: Session = Depends(get_db)) -> Evenement:
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    reservation_ids = database.query(Reservation.id).filter(Reservation.evenement_id == db_evenement.id).all()
    response_data = {
        "evenement": db_evenement,
        "reservation_ids": [x[0] for x in reservation_ids]}
    return response_data



@app.post("/evenement/", response_model=None, tags=["Evenement"])
async def create_evenement(evenement_data: EvenementCreate, database: Session = Depends(get_db)) -> Evenement:


    db_evenement = Evenement(
        dateFin=evenement_data.dateFin,        emailReferant=evenement_data.emailReferant,        description=evenement_data.description,        dateDebut=evenement_data.dateDebut,        nom=evenement_data.nom,        nbParticipant=evenement_data.nbParticipant        )

    database.add(db_evenement)
    database.commit()
    database.refresh(db_evenement)

    if evenement_data.reservation:
        # Validate that all Reservation IDs exist
        for reservation_id in evenement_data.reservation:
            db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
            if not db_reservation:
                raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

        # Update the related entities with the new foreign key
        database.query(Reservation).filter(Reservation.id.in_(evenement_data.reservation)).update(
            {Reservation.evenement_id: db_evenement.id}, synchronize_session=False
        )
        database.commit()



    reservation_ids = database.query(Reservation.id).filter(Reservation.evenement_id == db_evenement.id).all()
    response_data = {
        "evenement": db_evenement,
        "reservation_ids": [x[0] for x in reservation_ids]    }
    return response_data


@app.post("/evenement/bulk/", response_model=None, tags=["Evenement"])
async def bulk_create_evenement(items: list[EvenementCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Evenement entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_evenement = Evenement(
                dateFin=item_data.dateFin,                emailReferant=item_data.emailReferant,                description=item_data.description,                dateDebut=item_data.dateDebut,                nom=item_data.nom,                nbParticipant=item_data.nbParticipant            )
            database.add(db_evenement)
            database.flush()  # Get ID without committing
            created_items.append(db_evenement.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Evenement entities"
    }


@app.delete("/evenement/bulk/", response_model=None, tags=["Evenement"])
async def bulk_delete_evenement(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Evenement entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_evenement = database.query(Evenement).filter(Evenement.id == item_id).first()
        if db_evenement:
            database.delete(db_evenement)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Evenement entities"
    }

@app.put("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def update_evenement(evenement_id: int, evenement_data: EvenementCreate, database: Session = Depends(get_db)) -> Evenement:
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    setattr(db_evenement, 'dateFin', evenement_data.dateFin)
    setattr(db_evenement, 'emailReferant', evenement_data.emailReferant)
    setattr(db_evenement, 'description', evenement_data.description)
    setattr(db_evenement, 'dateDebut', evenement_data.dateDebut)
    setattr(db_evenement, 'nom', evenement_data.nom)
    setattr(db_evenement, 'nbParticipant', evenement_data.nbParticipant)
    if evenement_data.reservation is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Reservation).filter(Reservation.evenement_id == db_evenement.id).update(
            {Reservation.evenement_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if evenement_data.reservation:
            # Validate that all IDs exist
            for reservation_id in evenement_data.reservation:
                db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
                if not db_reservation:
                    raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

            # Update the related entities with the new foreign key
            database.query(Reservation).filter(Reservation.id.in_(evenement_data.reservation)).update(
                {Reservation.evenement_id: db_evenement.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_evenement)

    reservation_ids = database.query(Reservation.id).filter(Reservation.evenement_id == db_evenement.id).all()
    response_data = {
        "evenement": db_evenement,
        "reservation_ids": [x[0] for x in reservation_ids]    }
    return response_data


@app.delete("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def delete_evenement(evenement_id: int, database: Session = Depends(get_db)):
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")
    database.delete(db_evenement)
    database.commit()
    return db_evenement





############################################
#
#   Element functions
#
############################################

@app.get("/element/", response_model=None, tags=["Element"])
def get_all_element(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Element)
        query = query.options(joinedload(Element.centrecongres_1))
        query = query.options(joinedload(Element.tarif))
        element_list = query.all()

        # Serialize with relationships included
        result = []
        for element_item in element_list:
            item_dict = element_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if element_item.centrecongres_1:
                related_obj = element_item.centrecongres_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['centrecongres_1'] = related_dict
            else:
                item_dict['centrecongres_1'] = None
            if element_item.tarif:
                related_obj = element_item.tarif
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['tarif'] = related_dict
            else:
                item_dict['tarif'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            reservation_list = database.query(Reservation).filter(Reservation.element_1_id == element_item.id).all()
            item_dict['reservation_2'] = []
            for reservation_obj in reservation_list:
                reservation_dict = reservation_obj.__dict__.copy()
                reservation_dict.pop('_sa_instance_state', None)
                item_dict['reservation_2'].append(reservation_dict)
            indisponibilite_list = database.query(Indisponibilite).filter(Indisponibilite.element_3_id == element_item.id).all()
            item_dict['indisponibilite'] = []
            for indisponibilite_obj in indisponibilite_list:
                indisponibilite_dict = indisponibilite_obj.__dict__.copy()
                indisponibilite_dict.pop('_sa_instance_state', None)
                item_dict['indisponibilite'].append(indisponibilite_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Element).all()


@app.get("/element/count/", response_model=None, tags=["Element"])
def get_count_element(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Element entities"""
    count = database.query(Element).count()
    return {"count": count}


@app.get("/element/paginated/", response_model=None, tags=["Element"])
def get_paginated_element(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Element entities"""
    total = database.query(Element).count()
    element_list = database.query(Element).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": element_list
        }

    result = []
    for element_item in element_list:
        reservation_2_ids = database.query(Reservation.id).filter(Reservation.element_1_id == element_item.id).all()
        indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_3_id == element_item.id).all()
        item_data = {
            "element": element_item,
            "reservation_2_ids": [x[0] for x in reservation_2_ids],            "indisponibilite_ids": [x[0] for x in indisponibilite_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/element/search/", response_model=None, tags=["Element"])
def search_element(
    database: Session = Depends(get_db)
) -> list:
    """Search Element entities by attributes"""
    query = database.query(Element)


    results = query.all()
    return results


@app.get("/element/{element_id}/", response_model=None, tags=["Element"])
async def get_element(element_id: int, database: Session = Depends(get_db)) -> Element:
    db_element = database.query(Element).filter(Element.id == element_id).first()
    if db_element is None:
        raise HTTPException(status_code=404, detail="Element not found")

    reservation_2_ids = database.query(Reservation.id).filter(Reservation.element_1_id == db_element.id).all()
    indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_3_id == db_element.id).all()
    response_data = {
        "element": db_element,
        "reservation_2_ids": [x[0] for x in reservation_2_ids],        "indisponibilite_ids": [x[0] for x in indisponibilite_ids]}
    return response_data



@app.post("/element/", response_model=None, tags=["Element"])
async def create_element(element_data: ElementCreate, database: Session = Depends(get_db)) -> Element:

    if element_data.centrecongres_1 is not None:
        db_centrecongres_1 = database.query(CentreCongres).filter(CentreCongres.id == element_data.centrecongres_1).first()
        if not db_centrecongres_1:
            raise HTTPException(status_code=400, detail="CentreCongres not found")
    else:
        raise HTTPException(status_code=400, detail="CentreCongres ID is required")
    if element_data.tarif is not None:
        db_tarif = database.query(Tarif).filter(Tarif.id == element_data.tarif).first()
        if not db_tarif:
            raise HTTPException(status_code=400, detail="Tarif not found")
    else:
        raise HTTPException(status_code=400, detail="Tarif ID is required")

    db_element = Element(
        capaciteMax=element_data.capaciteMax,        nom=element_data.nom,        dureeMin=element_data.dureeMin,        statut=element_data.statut,        jourInterdit=element_data.jourInterdit.value,        centrecongres_1_id=element_data.centrecongres_1,        tarif_id=element_data.tarif        )

    database.add(db_element)
    database.commit()
    database.refresh(db_element)

    if element_data.reservation_2:
        # Validate that all Reservation IDs exist
        for reservation_id in element_data.reservation_2:
            db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
            if not db_reservation:
                raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

        # Update the related entities with the new foreign key
        database.query(Reservation).filter(Reservation.id.in_(element_data.reservation_2)).update(
            {Reservation.element_1_id: db_element.id}, synchronize_session=False
        )
        database.commit()
    if element_data.indisponibilite:
        # Validate that all Indisponibilite IDs exist
        for indisponibilite_id in element_data.indisponibilite:
            db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
            if not db_indisponibilite:
                raise HTTPException(status_code=400, detail=f"Indisponibilite with id {indisponibilite_id} not found")

        # Update the related entities with the new foreign key
        database.query(Indisponibilite).filter(Indisponibilite.id.in_(element_data.indisponibilite)).update(
            {Indisponibilite.element_3_id: db_element.id}, synchronize_session=False
        )
        database.commit()



    reservation_2_ids = database.query(Reservation.id).filter(Reservation.element_1_id == db_element.id).all()
    indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_3_id == db_element.id).all()
    response_data = {
        "element": db_element,
        "reservation_2_ids": [x[0] for x in reservation_2_ids],        "indisponibilite_ids": [x[0] for x in indisponibilite_ids]    }
    return response_data


@app.post("/element/bulk/", response_model=None, tags=["Element"])
async def bulk_create_element(items: list[ElementCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Element entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.centrecongres_1:
                raise ValueError("CentreCongres ID is required")
            if not item_data.tarif:
                raise ValueError("Tarif ID is required")

            db_element = Element(
                capaciteMax=item_data.capaciteMax,                nom=item_data.nom,                dureeMin=item_data.dureeMin,                statut=item_data.statut,                jourInterdit=item_data.jourInterdit.value,                centrecongres_1_id=item_data.centrecongres_1,                tarif_id=item_data.tarif            )
            database.add(db_element)
            database.flush()  # Get ID without committing
            created_items.append(db_element.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Element entities"
    }


@app.delete("/element/bulk/", response_model=None, tags=["Element"])
async def bulk_delete_element(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Element entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_element = database.query(Element).filter(Element.id == item_id).first()
        if db_element:
            database.delete(db_element)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Element entities"
    }

@app.put("/element/{element_id}/", response_model=None, tags=["Element"])
async def update_element(element_id: int, element_data: ElementCreate, database: Session = Depends(get_db)) -> Element:
    db_element = database.query(Element).filter(Element.id == element_id).first()
    if db_element is None:
        raise HTTPException(status_code=404, detail="Element not found")

    setattr(db_element, 'capaciteMax', element_data.capaciteMax)
    setattr(db_element, 'nom', element_data.nom)
    setattr(db_element, 'dureeMin', element_data.dureeMin)
    setattr(db_element, 'statut', element_data.statut)
    setattr(db_element, 'jourInterdit', element_data.jourInterdit.value)
    if element_data.centrecongres_1 is not None:
        db_centrecongres_1 = database.query(CentreCongres).filter(CentreCongres.id == element_data.centrecongres_1).first()
        if not db_centrecongres_1:
            raise HTTPException(status_code=400, detail="CentreCongres not found")
        setattr(db_element, 'centrecongres_1_id', element_data.centrecongres_1)
    if element_data.tarif is not None:
        db_tarif = database.query(Tarif).filter(Tarif.id == element_data.tarif).first()
        if not db_tarif:
            raise HTTPException(status_code=400, detail="Tarif not found")
        setattr(db_element, 'tarif_id', element_data.tarif)
    if element_data.reservation_2 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Reservation).filter(Reservation.element_1_id == db_element.id).update(
            {Reservation.element_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if element_data.reservation_2:
            # Validate that all IDs exist
            for reservation_id in element_data.reservation_2:
                db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
                if not db_reservation:
                    raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

            # Update the related entities with the new foreign key
            database.query(Reservation).filter(Reservation.id.in_(element_data.reservation_2)).update(
                {Reservation.element_1_id: db_element.id}, synchronize_session=False
            )
    if element_data.indisponibilite is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Indisponibilite).filter(Indisponibilite.element_3_id == db_element.id).update(
            {Indisponibilite.element_3_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if element_data.indisponibilite:
            # Validate that all IDs exist
            for indisponibilite_id in element_data.indisponibilite:
                db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
                if not db_indisponibilite:
                    raise HTTPException(status_code=400, detail=f"Indisponibilite with id {indisponibilite_id} not found")

            # Update the related entities with the new foreign key
            database.query(Indisponibilite).filter(Indisponibilite.id.in_(element_data.indisponibilite)).update(
                {Indisponibilite.element_3_id: db_element.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_element)

    reservation_2_ids = database.query(Reservation.id).filter(Reservation.element_1_id == db_element.id).all()
    indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_3_id == db_element.id).all()
    response_data = {
        "element": db_element,
        "reservation_2_ids": [x[0] for x in reservation_2_ids],        "indisponibilite_ids": [x[0] for x in indisponibilite_ids]    }
    return response_data


@app.delete("/element/{element_id}/", response_model=None, tags=["Element"])
async def delete_element(element_id: int, database: Session = Depends(get_db)):
    db_element = database.query(Element).filter(Element.id == element_id).first()
    if db_element is None:
        raise HTTPException(status_code=404, detail="Element not found")
    database.delete(db_element)
    database.commit()
    return db_element



############################################
#   Element Method Endpoints
############################################




@app.post("/element/methods/calculerTarif/", response_model=None, tags=["Element Methods"])
async def element_calculerTarif(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the calculerTarif class method on Element.
    This method operates on all Element entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebut: date    - dateFin: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebut = params.get('dateDebut')
        dateFin = params.get('dateFin')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Element",
            "method": "calculerTarif",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/element/methods/estDisponible/", response_model=None, tags=["Element Methods"])
async def element_estDisponible(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the estDisponible class method on Element.
    This method operates on all Element entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebut: date    - dateFin: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebut = params.get('dateDebut')
        dateFin = params.get('dateFin')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Element",
            "method": "estDisponible",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/element/methods/ajouterIndisponibilite/", response_model=None, tags=["Element Methods"])
async def element_ajouterIndisponibilite(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the ajouterIndisponibilite class method on Element.
    This method operates on all Element entities or performs class-level operations.

    Parameters (pass as JSON body):
    - i: Indisponibilite    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        i = await get_indisponibilite(params.get('i'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Element",
            "method": "ajouterIndisponibilite",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   CentreCongres functions
#
############################################

@app.get("/centrecongres/", response_model=None, tags=["CentreCongres"])
def get_all_centrecongres(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(CentreCongres)
        query = query.options(joinedload(CentreCongres.gestionnaire))
        centrecongres_list = query.all()

        # Serialize with relationships included
        result = []
        for centrecongres_item in centrecongres_list:
            item_dict = centrecongres_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if centrecongres_item.gestionnaire:
                related_obj = centrecongres_item.gestionnaire
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['gestionnaire'] = related_dict
            else:
                item_dict['gestionnaire'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            element_list = database.query(Element).filter(Element.centrecongres_1_id == centrecongres_item.id).all()
            item_dict['element'] = []
            for element_obj in element_list:
                element_dict = element_obj.__dict__.copy()
                element_dict.pop('_sa_instance_state', None)
                item_dict['element'].append(element_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(CentreCongres).all()


@app.get("/centrecongres/count/", response_model=None, tags=["CentreCongres"])
def get_count_centrecongres(database: Session = Depends(get_db)) -> dict:
    """Get the total count of CentreCongres entities"""
    count = database.query(CentreCongres).count()
    return {"count": count}


@app.get("/centrecongres/paginated/", response_model=None, tags=["CentreCongres"])
def get_paginated_centrecongres(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of CentreCongres entities"""
    total = database.query(CentreCongres).count()
    centrecongres_list = database.query(CentreCongres).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": centrecongres_list
        }

    result = []
    for centrecongres_item in centrecongres_list:
        element_ids = database.query(Element.id).filter(Element.centrecongres_1_id == centrecongres_item.id).all()
        item_data = {
            "centrecongres": centrecongres_item,
            "element_ids": [x[0] for x in element_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/centrecongres/search/", response_model=None, tags=["CentreCongres"])
def search_centrecongres(
    database: Session = Depends(get_db)
) -> list:
    """Search CentreCongres entities by attributes"""
    query = database.query(CentreCongres)


    results = query.all()
    return results


@app.get("/centrecongres/{centrecongres_id}/", response_model=None, tags=["CentreCongres"])
async def get_centrecongres(centrecongres_id: int, database: Session = Depends(get_db)) -> CentreCongres:
    db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
    if db_centrecongres is None:
        raise HTTPException(status_code=404, detail="CentreCongres not found")

    element_ids = database.query(Element.id).filter(Element.centrecongres_1_id == db_centrecongres.id).all()
    response_data = {
        "centrecongres": db_centrecongres,
        "element_ids": [x[0] for x in element_ids]}
    return response_data



@app.post("/centrecongres/", response_model=None, tags=["CentreCongres"])
async def create_centrecongres(centrecongres_data: CentreCongresCreate, database: Session = Depends(get_db)) -> CentreCongres:

    if centrecongres_data.gestionnaire is not None:
        db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == centrecongres_data.gestionnaire).first()
        if not db_gestionnaire:
            raise HTTPException(status_code=400, detail="Gestionnaire not found")
    else:
        raise HTTPException(status_code=400, detail="Gestionnaire ID is required")

    db_centrecongres = CentreCongres(
        description=centrecongres_data.description,        nom=centrecongres_data.nom,        adresse=centrecongres_data.adresse,        gestionnaire_id=centrecongres_data.gestionnaire        )

    database.add(db_centrecongres)
    database.commit()
    database.refresh(db_centrecongres)

    if centrecongres_data.element:
        # Validate that all Element IDs exist
        for element_id in centrecongres_data.element:
            db_element = database.query(Element).filter(Element.id == element_id).first()
            if not db_element:
                raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

        # Update the related entities with the new foreign key
        database.query(Element).filter(Element.id.in_(centrecongres_data.element)).update(
            {Element.centrecongres_1_id: db_centrecongres.id}, synchronize_session=False
        )
        database.commit()



    element_ids = database.query(Element.id).filter(Element.centrecongres_1_id == db_centrecongres.id).all()
    response_data = {
        "centrecongres": db_centrecongres,
        "element_ids": [x[0] for x in element_ids]    }
    return response_data


@app.post("/centrecongres/bulk/", response_model=None, tags=["CentreCongres"])
async def bulk_create_centrecongres(items: list[CentreCongresCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple CentreCongres entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.gestionnaire:
                raise ValueError("Gestionnaire ID is required")

            db_centrecongres = CentreCongres(
                description=item_data.description,                nom=item_data.nom,                adresse=item_data.adresse,                gestionnaire_id=item_data.gestionnaire            )
            database.add(db_centrecongres)
            database.flush()  # Get ID without committing
            created_items.append(db_centrecongres.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} CentreCongres entities"
    }


@app.delete("/centrecongres/bulk/", response_model=None, tags=["CentreCongres"])
async def bulk_delete_centrecongres(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple CentreCongres entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == item_id).first()
        if db_centrecongres:
            database.delete(db_centrecongres)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} CentreCongres entities"
    }

@app.put("/centrecongres/{centrecongres_id}/", response_model=None, tags=["CentreCongres"])
async def update_centrecongres(centrecongres_id: int, centrecongres_data: CentreCongresCreate, database: Session = Depends(get_db)) -> CentreCongres:
    db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
    if db_centrecongres is None:
        raise HTTPException(status_code=404, detail="CentreCongres not found")

    setattr(db_centrecongres, 'description', centrecongres_data.description)
    setattr(db_centrecongres, 'nom', centrecongres_data.nom)
    setattr(db_centrecongres, 'adresse', centrecongres_data.adresse)
    if centrecongres_data.gestionnaire is not None:
        db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == centrecongres_data.gestionnaire).first()
        if not db_gestionnaire:
            raise HTTPException(status_code=400, detail="Gestionnaire not found")
        setattr(db_centrecongres, 'gestionnaire_id', centrecongres_data.gestionnaire)
    if centrecongres_data.element is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Element).filter(Element.centrecongres_1_id == db_centrecongres.id).update(
            {Element.centrecongres_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if centrecongres_data.element:
            # Validate that all IDs exist
            for element_id in centrecongres_data.element:
                db_element = database.query(Element).filter(Element.id == element_id).first()
                if not db_element:
                    raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

            # Update the related entities with the new foreign key
            database.query(Element).filter(Element.id.in_(centrecongres_data.element)).update(
                {Element.centrecongres_1_id: db_centrecongres.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_centrecongres)

    element_ids = database.query(Element.id).filter(Element.centrecongres_1_id == db_centrecongres.id).all()
    response_data = {
        "centrecongres": db_centrecongres,
        "element_ids": [x[0] for x in element_ids]    }
    return response_data


@app.delete("/centrecongres/{centrecongres_id}/", response_model=None, tags=["CentreCongres"])
async def delete_centrecongres(centrecongres_id: int, database: Session = Depends(get_db)):
    db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
    if db_centrecongres is None:
        raise HTTPException(status_code=404, detail="CentreCongres not found")
    database.delete(db_centrecongres)
    database.commit()
    return db_centrecongres



############################################
#   CentreCongres Method Endpoints
############################################




@app.post("/centrecongres/methods/getEvenementsPrevus/", response_model=None, tags=["CentreCongres Methods"])
async def centrecongres_getEvenementsPrevus(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the getEvenementsPrevus class method on CentreCongres.
    This method operates on all CentreCongres entities or performs class-level operations.

    Parameters (pass as JSON body):
    - elmt: Element    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        elmt = await get_element(params.get('elmt'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "CentreCongres",
            "method": "getEvenementsPrevus",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/centrecongres/methods/getGains/", response_model=None, tags=["CentreCongres Methods"])
async def centrecongres_getGains(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the getGains class method on CentreCongres.
    This method operates on all CentreCongres entities or performs class-level operations.

    Parameters (pass as JSON body):
    - elmt: Element    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        elmt = await get_element(params.get('elmt'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "CentreCongres",
            "method": "getGains",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/centrecongres/methods/getEvenementsPasses/", response_model=None, tags=["CentreCongres Methods"])
async def centrecongres_getEvenementsPasses(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the getEvenementsPasses class method on CentreCongres.
    This method operates on all CentreCongres entities or performs class-level operations.

    Parameters (pass as JSON body):
    - elmt: Element    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        elmt = await get_element(params.get('elmt'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "CentreCongres",
            "method": "getEvenementsPasses",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Gestionnaire functions
#
############################################

@app.get("/gestionnaire/", response_model=None, tags=["Gestionnaire"])
def get_all_gestionnaire(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Gestionnaire)
        gestionnaire_list = query.all()

        # Serialize with relationships included
        result = []
        for gestionnaire_item in gestionnaire_list:
            item_dict = gestionnaire_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            centrecongres_list = database.query(CentreCongres).filter(CentreCongres.gestionnaire_id == gestionnaire_item.id).all()
            item_dict['centrecongres'] = []
            for centrecongres_obj in centrecongres_list:
                centrecongres_dict = centrecongres_obj.__dict__.copy()
                centrecongres_dict.pop('_sa_instance_state', None)
                item_dict['centrecongres'].append(centrecongres_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Gestionnaire).all()


@app.get("/gestionnaire/count/", response_model=None, tags=["Gestionnaire"])
def get_count_gestionnaire(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Gestionnaire entities"""
    count = database.query(Gestionnaire).count()
    return {"count": count}


@app.get("/gestionnaire/paginated/", response_model=None, tags=["Gestionnaire"])
def get_paginated_gestionnaire(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Gestionnaire entities"""
    total = database.query(Gestionnaire).count()
    gestionnaire_list = database.query(Gestionnaire).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": gestionnaire_list
        }

    result = []
    for gestionnaire_item in gestionnaire_list:
        centrecongres_ids = database.query(CentreCongres.id).filter(CentreCongres.gestionnaire_id == gestionnaire_item.id).all()
        item_data = {
            "gestionnaire": gestionnaire_item,
            "centrecongres_ids": [x[0] for x in centrecongres_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/gestionnaire/search/", response_model=None, tags=["Gestionnaire"])
def search_gestionnaire(
    database: Session = Depends(get_db)
) -> list:
    """Search Gestionnaire entities by attributes"""
    query = database.query(Gestionnaire)


    results = query.all()
    return results


@app.get("/gestionnaire/{gestionnaire_id}/", response_model=None, tags=["Gestionnaire"])
async def get_gestionnaire(gestionnaire_id: int, database: Session = Depends(get_db)) -> Gestionnaire:
    db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
    if db_gestionnaire is None:
        raise HTTPException(status_code=404, detail="Gestionnaire not found")

    centrecongres_ids = database.query(CentreCongres.id).filter(CentreCongres.gestionnaire_id == db_gestionnaire.id).all()
    response_data = {
        "gestionnaire": db_gestionnaire,
        "centrecongres_ids": [x[0] for x in centrecongres_ids]}
    return response_data



@app.post("/gestionnaire/", response_model=None, tags=["Gestionnaire"])
async def create_gestionnaire(gestionnaire_data: GestionnaireCreate, database: Session = Depends(get_db)) -> Gestionnaire:


    db_gestionnaire = Gestionnaire(
        nom=gestionnaire_data.nom,        email=gestionnaire_data.email,        prenom=gestionnaire_data.prenom        )

    database.add(db_gestionnaire)
    database.commit()
    database.refresh(db_gestionnaire)

    if gestionnaire_data.centrecongres:
        # Validate that all CentreCongres IDs exist
        for centrecongres_id in gestionnaire_data.centrecongres:
            db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
            if not db_centrecongres:
                raise HTTPException(status_code=400, detail=f"CentreCongres with id {centrecongres_id} not found")

        # Update the related entities with the new foreign key
        database.query(CentreCongres).filter(CentreCongres.id.in_(gestionnaire_data.centrecongres)).update(
            {CentreCongres.gestionnaire_id: db_gestionnaire.id}, synchronize_session=False
        )
        database.commit()



    centrecongres_ids = database.query(CentreCongres.id).filter(CentreCongres.gestionnaire_id == db_gestionnaire.id).all()
    response_data = {
        "gestionnaire": db_gestionnaire,
        "centrecongres_ids": [x[0] for x in centrecongres_ids]    }
    return response_data


@app.post("/gestionnaire/bulk/", response_model=None, tags=["Gestionnaire"])
async def bulk_create_gestionnaire(items: list[GestionnaireCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Gestionnaire entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_gestionnaire = Gestionnaire(
                nom=item_data.nom,                email=item_data.email,                prenom=item_data.prenom            )
            database.add(db_gestionnaire)
            database.flush()  # Get ID without committing
            created_items.append(db_gestionnaire.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Gestionnaire entities"
    }


@app.delete("/gestionnaire/bulk/", response_model=None, tags=["Gestionnaire"])
async def bulk_delete_gestionnaire(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Gestionnaire entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == item_id).first()
        if db_gestionnaire:
            database.delete(db_gestionnaire)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Gestionnaire entities"
    }

@app.put("/gestionnaire/{gestionnaire_id}/", response_model=None, tags=["Gestionnaire"])
async def update_gestionnaire(gestionnaire_id: int, gestionnaire_data: GestionnaireCreate, database: Session = Depends(get_db)) -> Gestionnaire:
    db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
    if db_gestionnaire is None:
        raise HTTPException(status_code=404, detail="Gestionnaire not found")

    setattr(db_gestionnaire, 'nom', gestionnaire_data.nom)
    setattr(db_gestionnaire, 'email', gestionnaire_data.email)
    setattr(db_gestionnaire, 'prenom', gestionnaire_data.prenom)
    if gestionnaire_data.centrecongres is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(CentreCongres).filter(CentreCongres.gestionnaire_id == db_gestionnaire.id).update(
            {CentreCongres.gestionnaire_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if gestionnaire_data.centrecongres:
            # Validate that all IDs exist
            for centrecongres_id in gestionnaire_data.centrecongres:
                db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
                if not db_centrecongres:
                    raise HTTPException(status_code=400, detail=f"CentreCongres with id {centrecongres_id} not found")

            # Update the related entities with the new foreign key
            database.query(CentreCongres).filter(CentreCongres.id.in_(gestionnaire_data.centrecongres)).update(
                {CentreCongres.gestionnaire_id: db_gestionnaire.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_gestionnaire)

    centrecongres_ids = database.query(CentreCongres.id).filter(CentreCongres.gestionnaire_id == db_gestionnaire.id).all()
    response_data = {
        "gestionnaire": db_gestionnaire,
        "centrecongres_ids": [x[0] for x in centrecongres_ids]    }
    return response_data


@app.delete("/gestionnaire/{gestionnaire_id}/", response_model=None, tags=["Gestionnaire"])
async def delete_gestionnaire(gestionnaire_id: int, database: Session = Depends(get_db)):
    db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
    if db_gestionnaire is None:
        raise HTTPException(status_code=404, detail="Gestionnaire not found")
    database.delete(db_gestionnaire)
    database.commit()
    return db_gestionnaire



############################################
#   Gestionnaire Method Endpoints
############################################




@app.post("/gestionnaire/methods/supprimerElement/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_supprimerElement(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the supprimerElement class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - centre: CentreCongres    - elmt: Element    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        centre = await get_centrecongres(params.get('centre'), database)
        elmt = await get_element(params.get('elmt'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "supprimerElement",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/getDisponibiliteElement/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_getDisponibiliteElement(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the getDisponibiliteElement class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - elmt: Element    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        elmt = await get_element(params.get('elmt'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "getDisponibiliteElement",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/modifierReservation/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_modifierReservation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the modifierReservation class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - centre: CentreCongres    - evenement: Evenement    - r: Reservation    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        centre = await get_centrecongres(params.get('centre'), database)
        evenement = await get_evenement(params.get('evenement'), database)
        r = await get_reservation(params.get('r'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "modifierReservation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/getElements/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_getElements(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the getElements class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - centre: CentreCongres    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        centre = await get_centrecongres(params.get('centre'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "getElements",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/getReservations/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_getReservations(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the getReservations class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - centre: CentreCongres    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        centre = await get_centrecongres(params.get('centre'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "getReservations",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/getStats/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_getStats(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the getStats class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - centre: CentreCongres    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        centre = await get_centrecongres(params.get('centre'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "getStats",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/ajouterReservation/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_ajouterReservation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the ajouterReservation class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - centre: CentreCongres    - evenement: Evenement    - r: Reservation    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        centre = await get_centrecongres(params.get('centre'), database)
        evenement = await get_evenement(params.get('evenement'), database)
        r = await get_reservation(params.get('r'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "ajouterReservation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/ajouterElement/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_ajouterElement(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the ajouterElement class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - centre: CentreCongres    - elmt: Element    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        centre = await get_centrecongres(params.get('centre'), database)
        elmt = await get_element(params.get('elmt'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "ajouterElement",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/modifierTarif/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_modifierTarif(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the modifierTarif class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - elmnt: Element    - tarif: Tarif    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        elmnt = await get_element(params.get('elmnt'), database)
        tarif = await get_tarif(params.get('tarif'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "modifierTarif",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






############################################
# Maintaining the server
############################################
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)



