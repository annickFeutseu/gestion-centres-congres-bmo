from datetime import datetime, date, time
from typing import Any, List, Optional, Union, Set
from enum import Enum
from pydantic import BaseModel, field_validator

from abc import ABC, abstractmethod

############################################
# Enumerations are defined here
############################################

class Saison(Enum):
    BASSE = "BASSE"
    MOYENNE = "MOYENNE"
    HAUTE = "HAUTE"

class ReservationStatut(Enum):
    CONFIRME = "CONFIRME"
    EN_ATTENTE = "EN_ATTENTE"
    ANNULEE = "ANNULEE"

class JourSemaine(Enum):
    Mardi = "Mardi"
    Jeudi = "Jeudi"
    Samedi = "Samedi"
    Dimanche = "Dimanche"
    Mercredi = "Mercredi"
    Lundi = "Lundi"
    Vendredi = "Vendredi"

############################################
# Classes are defined here
############################################
class IndisponibiliteCreate(BaseModel):
    dateFin: date
    motif: str
    dateDebut: date
    element_3: int  # N:1 Relationship (mandatory)


class TarifCreate(BaseModel):
    saison: Saison
    prix: float
    element_2: Optional[List[int]] = None  # 1:N Relationship


class SupplementCreate(ABC, BaseModel):
    nom: str
    prix: float
    quantiteMax: int
    reservation_1: int  # N:1 Relationship (mandatory)


class MaterielCreate(SupplementCreate):
    quantiteDispo: int


class PrestationCreate(SupplementCreate):
    typePrestation: str


class ReservationCreate(BaseModel):
    dateFin: date
    dateLimiteconfirmation: date
    statut: ReservationStatut
    dateDeb: date
    evenement: int  # N:1 Relationship (mandatory)
    supplement: Optional[List[int]] = None  # 1:N Relationship
    element_1: int  # N:1 Relationship (mandatory)


class EvenementCreate(BaseModel):
    dateFin: date
    emailReferant: str
    description: str
    dateDebut: date
    nom: str
    nbParticipant: int
    reservation: Optional[List[int]] = None  # 1:N Relationship


class ElementCreate(BaseModel):
    capaciteMax: int
    nom: str
    dureeMin: int
    statut: bool
    jourInterdit: JourSemaine
    reservation_2: Optional[List[int]] = None  # 1:N Relationship
    indisponibilite: Optional[List[int]] = None  # 1:N Relationship
    centrecongres_1: int  # N:1 Relationship (mandatory)
    tarif: int  # N:1 Relationship (mandatory)


class CentreCongresCreate(BaseModel):
    description: str
    nom: str
    adresse: str
    gestionnaire: int  # N:1 Relationship (mandatory)
    element: Optional[List[int]] = None  # 1:N Relationship


class GestionnaireCreate(BaseModel):
    nom: str
    email: str
    prenom: str
    centrecongres: Optional[List[int]] = None  # 1:N Relationship


