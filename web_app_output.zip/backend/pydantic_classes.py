from datetime import datetime, date, time
from typing import Any, List, Optional, Union, Set
from enum import Enum
from pydantic import BaseModel, field_validator

from abc import ABC, abstractmethod

############################################
# Enumerations are defined here
############################################

class JourSemaine(Enum):
    Mercredi = "Mercredi"
    Jeudi = "Jeudi"
    Vendredi = "Vendredi"
    Mardi = "Mardi"
    Dimanche = "Dimanche"
    Lundi = "Lundi"
    Samedi = "Samedi"

class ReservationStatut(Enum):
    ANNULEE = "ANNULEE"
    CONFIRME = "CONFIRME"
    EN_ATTENTE = "EN_ATTENTE"

class Saison(Enum):
    BASSE = "BASSE"
    HAUTE = "HAUTE"
    MOYENNE = "MOYENNE"

############################################
# Classes are defined here
############################################
class IndisponibiliteCreate(BaseModel):
    dateDebut: date
    dateFin: date
    motif: str
    element_3: Optional[int] = None  # N:1 Relationship (optional)


class TarifCreate(BaseModel):
    prix: float
    saison: Saison
    element_2: Optional[List[int]] = None  # 1:N Relationship


class SupplementCreate(ABC, BaseModel):
    quantiteMax: int
    nom: str
    prix: float
    reservation_1: Optional[int] = None  # N:1 Relationship (optional)


class MaterielCreate(SupplementCreate):
    quantiteDispo: int


class PrestationCreate(SupplementCreate):
    typePrestation: str


class ReservationCreate(BaseModel):
    dateFin: date
    statut: ReservationStatut
    dateDeb: date
    dateLimiteconfirmation: date
    supplement: Optional[List[int]] = None  # 1:N Relationship
    element_1: Optional[int] = None  # N:1 Relationship (optional)
    evenement: Optional[int] = None  # N:1 Relationship (optional)


class EvenementCreate(BaseModel):
    emailReferant: str
    nbParticipant: int
    dateFin: date
    nom: str
    description: Optional[str] = None
    dateDebut: date
    reservation: Optional[List[int]] = None  # 1:N Relationship


class ElementCreate(BaseModel):
    capaciteMax: int
    actif: Optional[bool] = None
    jourInterdit: Optional[JourSemaine] = None
    dureeMin: int
    nom: str
    centrecongres_1: int  # N:1 Relationship (mandatory)
    indisponibilite: Optional[List[int]] = None  # 1:N Relationship
    reservation_2: Optional[List[int]] = None  # 1:N Relationship
    tarif: Optional[int] = None  # N:1 Relationship (optional)


class CentreCongresCreate(BaseModel):
    adresse: str
    description: Optional[str] = None
    nom: str
    element: Optional[List[int]] = None  # 1:N Relationship
    gestionnaire: Optional[int] = None  # N:1 Relationship (optional)


class GestionnaireCreate(BaseModel):
    nom: str
    prenom: str
    email: str
    centrecongres: Optional[List[int]] = None  # 1:N Relationship


