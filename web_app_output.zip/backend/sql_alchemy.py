import enum
from typing import List, Optional
from sqlalchemy import (
    create_engine, Column, ForeignKey, Table, Text, Boolean, String, Date, 
    Time, DateTime, Float, Integer, Enum
)
from sqlalchemy.ext.declarative import AbstractConcreteBase
from sqlalchemy.orm import (
    column_property, DeclarativeBase, Mapped, mapped_column, relationship
)
from datetime import datetime as dt_datetime, time as dt_time, date as dt_date

class Base(DeclarativeBase):
    pass

# Definitions of Enumerations
class Saison(enum.Enum):
    BASSE = "BASSE"
    MOYENNE = "MOYENNE"
    HAUTE = "HAUTE"

class ReservationStatut(enum.Enum):
    CONFIRME = "CONFIRME"
    EN_ATTENTE = "EN_ATTENTE"
    ANNULEE = "ANNULEE"

class JourSemaine(enum.Enum):
    Mardi = "Mardi"
    Jeudi = "Jeudi"
    Samedi = "Samedi"
    Dimanche = "Dimanche"
    Mercredi = "Mercredi"
    Lundi = "Lundi"
    Vendredi = "Vendredi"


# Tables definition for many-to-many relationships

# Tables definition
class Indisponibilite(Base):
    __tablename__ = "indisponibilite"
    id: Mapped[int] = mapped_column(primary_key=True)
    dateDebut: Mapped[dt_date] = mapped_column(Date)
    dateFin: Mapped[dt_date] = mapped_column(Date)
    motif: Mapped[str] = mapped_column(String(100))
    element_3_id: Mapped[int] = mapped_column(ForeignKey("element.id"))

class Tarif(Base):
    __tablename__ = "tarif"
    id: Mapped[int] = mapped_column(primary_key=True)
    prix: Mapped[float] = mapped_column(Float)
    saison: Mapped[Saison] = mapped_column(Enum(Saison))

class Supplement(Base):
    __tablename__ = "supplement"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    quantiteMax: Mapped[int] = mapped_column(Integer)
    prix: Mapped[float] = mapped_column(Float)
    reservation_1_id: Mapped[int] = mapped_column(ForeignKey("reservation.id"))
    type_spec: Mapped[str] = mapped_column(String(50))
    __mapper_args__ = {
        "polymorphic_identity": "supplement",
        "polymorphic_on": "type_spec",
    }

class Materiel(Supplement):
    __tablename__ = "materiel"
    id: Mapped[int] = mapped_column(ForeignKey("supplement.id"), primary_key=True)
    quantiteDispo: Mapped[int] = mapped_column(Integer)
    __mapper_args__ = {
        "polymorphic_identity": "materiel",
    }

class Prestation(Supplement):
    __tablename__ = "prestation"
    id: Mapped[int] = mapped_column(ForeignKey("supplement.id"), primary_key=True)
    typePrestation: Mapped[str] = mapped_column(String(100))
    __mapper_args__ = {
        "polymorphic_identity": "prestation",
    }

class Reservation(Base):
    __tablename__ = "reservation"
    id: Mapped[int] = mapped_column(primary_key=True)
    dateDeb: Mapped[dt_date] = mapped_column(Date)
    dateFin: Mapped[dt_date] = mapped_column(Date)
    statut: Mapped[ReservationStatut] = mapped_column(Enum(ReservationStatut))
    dateLimiteconfirmation: Mapped[dt_date] = mapped_column(Date)
    element_1_id: Mapped[int] = mapped_column(ForeignKey("element.id"))
    evenement_id: Mapped[int] = mapped_column(ForeignKey("evenement.id"))

class Evenement(Base):
    __tablename__ = "evenement"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(String(100))
    nbParticipant: Mapped[int] = mapped_column(Integer)
    emailReferant: Mapped[str] = mapped_column(String(100))
    dateDebut: Mapped[dt_date] = mapped_column(Date)
    dateFin: Mapped[dt_date] = mapped_column(Date)

class Element(Base):
    __tablename__ = "element"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    capaciteMax: Mapped[int] = mapped_column(Integer)
    dureeMin: Mapped[int] = mapped_column(Integer)
    statut: Mapped[bool] = mapped_column(Boolean)
    jourInterdit: Mapped[JourSemaine] = mapped_column(Enum(JourSemaine))
    tarif_id: Mapped[int] = mapped_column(ForeignKey("tarif.id"))
    centrecongres_1_id: Mapped[int] = mapped_column(ForeignKey("centrecongres.id"))

class CentreCongres(Base):
    __tablename__ = "centrecongres"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    adresse: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(String(100))
    gestionnaire_id: Mapped[int] = mapped_column(ForeignKey("gestionnaire.id"))

class Gestionnaire(Base):
    __tablename__ = "gestionnaire"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    prenom: Mapped[str] = mapped_column(String(100))
    email: Mapped[str] = mapped_column(String(100))


#--- Relationships of the indisponibilite table
Indisponibilite.element_3: Mapped["Element"] = relationship("Element", back_populates="indisponibilite", foreign_keys=[Indisponibilite.element_3_id])

#--- Relationships of the tarif table
Tarif.element_2: Mapped[List["Element"]] = relationship("Element", back_populates="tarif", foreign_keys=[Element.tarif_id])

#--- Relationships of the supplement table
Supplement.reservation_1: Mapped["Reservation"] = relationship("Reservation", back_populates="supplement", foreign_keys=[Supplement.reservation_1_id])

#--- Relationships of the reservation table
Reservation.supplement: Mapped[List["Supplement"]] = relationship("Supplement", back_populates="reservation_1", foreign_keys=[Supplement.reservation_1_id])
Reservation.element_1: Mapped["Element"] = relationship("Element", back_populates="reservation_2", foreign_keys=[Reservation.element_1_id])
Reservation.evenement: Mapped["Evenement"] = relationship("Evenement", back_populates="reservation", foreign_keys=[Reservation.evenement_id])

#--- Relationships of the evenement table
Evenement.reservation: Mapped[List["Reservation"]] = relationship("Reservation", back_populates="evenement", foreign_keys=[Reservation.evenement_id])

#--- Relationships of the element table
Element.tarif: Mapped["Tarif"] = relationship("Tarif", back_populates="element_2", foreign_keys=[Element.tarif_id])
Element.reservation_2: Mapped[List["Reservation"]] = relationship("Reservation", back_populates="element_1", foreign_keys=[Reservation.element_1_id])
Element.centrecongres_1: Mapped["CentreCongres"] = relationship("CentreCongres", back_populates="element", foreign_keys=[Element.centrecongres_1_id])
Element.indisponibilite: Mapped[List["Indisponibilite"]] = relationship("Indisponibilite", back_populates="element_3", foreign_keys=[Indisponibilite.element_3_id])

#--- Relationships of the centrecongres table
CentreCongres.element: Mapped[List["Element"]] = relationship("Element", back_populates="centrecongres_1", foreign_keys=[Element.centrecongres_1_id])
CentreCongres.gestionnaire: Mapped["Gestionnaire"] = relationship("Gestionnaire", back_populates="centrecongres", foreign_keys=[CentreCongres.gestionnaire_id])

#--- Relationships of the gestionnaire table
Gestionnaire.centrecongres: Mapped[List["CentreCongres"]] = relationship("CentreCongres", back_populates="gestionnaire", foreign_keys=[CentreCongres.gestionnaire_id])

# Database connection
DATABASE_URL = "sqlite:///Class_Diagram.db"  # SQLite connection
engine = create_engine(DATABASE_URL, echo=True)

# Create tables in the database
Base.metadata.create_all(engine, checkfirst=True)